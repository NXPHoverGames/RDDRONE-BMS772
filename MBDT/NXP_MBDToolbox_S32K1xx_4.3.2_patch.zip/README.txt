This readme explains how to add the patch and open the BMS app example for the RDDRONE-BMS772 NXP board.

Prerequisite:
•	The application works for MATLAB2020a or newer versions
•	You have seen the BMS772 example page
	o	https://community.nxp.com/t5/NXP-Model-Based-Design-Tools/Example-Model-RDDRONE-BMS772/ta-p/1550394 
•	You have seen the MBDT QuickStart guide
	o	https://www.nxp.com/docs/en/quick-reference-guide/MBDT-S32K1xx_QSG.pdf 
•	Have a J-link base programmer and cables
•	Have JLink installed at the default path
	o	C:\Program Files\SEGGER\JLink (or alternatively update the JLink path in the Simulink model settings)
•	Have a BMS772 box
	o	RDDRONE-BMS772
	o	Solder the cell configuration jumpers
			See https://nxp.gitbook.io/rddrone-bms772/user-guide/getting-started-with-the-rddrone-bms772/configuring-the-hardware#cell-terminal-connection 
	o	Solder the correct balance connector
	o	Optional: Solder XT90 connectors
	o	Optional: place display
	o	Optional: hook up NTC for temperature sensor.
•	Have a DCD-LZ (FTDI + programmer to 7 pins JST).
•	Have an 3V3 FTDI cable
•	Have MATLAB Simulink.
•	Install the required toolboxes which can be found in the readme of the BMS application

How to add the patch and open the RDDRONE-BMS772 BMS app example:
1.	Get the s32k1xx support package 
	a.	Go to https://nl.mathworks.com/matlabcentral/fileexchange/64740-nxp-support-package-s32k1xx 
	b.	Download the toolbox
	d.	Open the location of this support package in  MATLAB
	e.	Open the .m and run this file in MATLAB
2.	Install the toolbox
	a.	Go to https://nxp.flexnetoperations.com/control/frse/product?entitlementId=581904417&lineNum=1&authContactId=140972577&authPartyId=157528577
	b.	And navigate to https://nxp.flexnetoperations.com/control/frse/download?element=13727287
	c.	Download the mltbx file.
	d.	Rename the downloaded .zip to .mltbx to change the file type
	e.	Open in MATLAB
	f.	Install it.
	g.	Verify the installation in the toolbox guide
3.	Generate the license
	a.	In flexnetoperations navigate to Model-Based Design Toolbox > Model-Based Design Toolbox for S32K1xx Automotive Microprocessors Family files (Product download page)
	c.	Click license keys
	d.	Select the box, generate.
	e.	You need you disk serial number, open command prompt (CMD) and type “VOL”, you get you serial number
	f.	For the name: you can add the laptop name
	g.	Click View (bottom right)
	h.	Save all and choose location
	i.	Go back to MATLAB and chose activate NXP MBD toolbox
	j.	Then Verify MBD toolbox license
4.	How to get the new BMS772 BMS MBDT example running
	a.	Download and extract the S32K1xx_4.3.2 patch
	b.	Open MATLAB and run the NXP_MBDToolbox_S32K1xx_patch.m script
		i.	Right-click on the patch.m open with MATLAB. 
		ii.	In MATLAB click run
		iii.	Select change folder
		iv.	It will run and you will see “Patch was installed successfully!” 
			1.	If failed, try to run MATLAB with admin rights.
5.	How to open the BMS772 BMS app example(s)
	a.	Open MATLAB Simulink
	b.	Open a new blank model
	c.	Click on the library browser
	d.	Open the S32k1xx example projects library
		i.	NXP Model-Based Design Toolbox for S32k1xx MCUs -> S32K1xx Example Projects
		ii. 	Right click this and select "Open S32K1xx Example Projects library"
		iii. 	Select S32K14x MCU Simulink Models.
	e.	Then go to RDDRONE – BMS772
	f. 	Open RDDRONE BMS Application (rddrone_bms_app)
		i. This will open the BMS application in MBDT.
	g. 	Run the Run_me_first.m script in MATLAB 
		i. 	Make sure the MATLAB path is at: "..\NXP_MBDToolbox_S32K1xx\S32_Examples\s32k14x\rddrone\rddrone_bms_app\Settings"
		ii. 	Run the Run_me_first.m script.
	g.	To verify the model, please go to APPS -> Embedded Coder -> Generate Code (via Build menu)
		i. 	You should see that the code was build.
6.	How to change settings of the BMS772 BMS MBDT example
	b.	In the MATLAB explorer, go into the settings folder of the BMS app and open BMS_settings.m
		i.	You can change settings you need.
		ii.	Also change the LiPo_settings.m or the LiFe_settings.m if needed (for example the voltages)
	c.	Build with the new settings.
