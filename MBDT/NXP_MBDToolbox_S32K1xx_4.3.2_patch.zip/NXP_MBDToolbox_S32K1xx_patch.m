%NXP_MBDToolbox_S32K1xx_patch

% Copyright 2021-2024 NXP
%
% NXP Confidential and Proprietary. This software is owned or controlled by
% NXP and may only be used strictly in accordance with the applicable
% license terms. By expressly accepting such terms or by downloading,
% installing, activating and/or otherwise using the software, you are
% agreeing that you have read, and that you agree to comply with and are
% bound by, such license terms. If you do not agree to be bound by the
% applicable license terms, then you may not retain, install, activate or
% otherwise use the software.

function status = NXP_MBDToolbox_S32K1xx_patch()
    tbxName = 'NXP_MBDToolbox_S32K1xx';
    patchName = 'NXP_MBDToolbox_S32K1xx_4.3.2_patch_20250319';
    
    fprintf('\nInstalling patch: %s ...\n\n', patchName);
    
    clear('mex'); %#ok<CLMEX>
    
    status = 0;
    
    modifiedFiles = {
        
        'Contents.m'
        'S32_Examples\demos.xml'
        'S32_Examples\mbd_s32k_examples.mdl'
        'S32_Examples\s32k14x\rddrone\rddrone_bms_app\README.md'
        'S32_Examples\s32k14x\rddrone\rddrone_bms_app\rddrone_bms_app.slx'
        'S32_Examples\s32k14x\rddrone\rddrone_bms_app\Settings\BMS_settings.m'
        'S32_Examples\s32k14x\rddrone\rddrone_bms_app\Settings\LiFe_settings.m'
        'S32_Examples\s32k14x\rddrone\rddrone_bms_app\Settings\LiPo_settings.m'
        'S32_Examples\s32k14x\rddrone\rddrone_bms_app\Settings\Run_me_first.m'
        'S32_Platform_SDK\platform\drivers\src\lpuart\lin_lpuart_driver.c'
        'external_devices\blocks\mc3377xc\mc3377xc_s32k_tpl_disen.tlc'
        'mbdtbx_s32k\mbd_s32k1xx_ec_toolbox.mdl'
        'mbdtbx_s32k\blocks\flash\flash_s32k_eeewrite.tlc'
        'mbdtbx_s32k\blocks\fm\fm_s32k_config.tlc'
        'mbdtbx_s32k\blocks\lpi2c\lpi2c_s32k_config.tlc'
        'mbdtbx_s32k\blocks\lpi2c\lpi2c_s32k_disen.tlc'
        'mbdtbx_s32k\blocks\lpi2c\lpi2c_s32k_isr.tlc'
        'mbdtbx_s32k\blocks\lpi2c\lpi2c_s32k_slave_receive.tlc'
        'mbdtbx_s32k\blocks\lpi2c\lpi2c_s32k_slave_transmit.tlc'
        'mbdtbx_s32k\blocks\lptmr\lptmr_s32k_isr.tlc'
        'mbdtbx_s32k\help\fm\fm_config.html'
        'mbdtbx_s32k\help\fm\fm_config_files\fm_config_bitrate.jpg'
        'mbdtbx_s32k\mscripts\fcan\mbd_s32k_fcan_mbconfig_sdk_params.p'
        'mbdtbx_s32k\mscripts\fm\mbd_s32k_fm_config_cbk.p'
        'mbdtbx_s32k\mscripts\fm\mbd_s32k_fm_config_init.p'
        'mbdtbx_s32k\mscripts\fm\mbd_s32k_fm_config_sdk_params.p'
        'mbdtbx_s32k\mscripts\fm\mbd_s32k_fm_fcan_config_cbk.p'
        'mbdtbx_s32k\mscripts\lptmr\mbd_s32k_lptmr_isr_params.p'
        'mbdtbx_s32k\mscripts\model\mbd_s32k_model_init_fcn.p'
        'mbdtbx_s32k\mscripts\pmc\mbd_s32k_pmc_config_cbk.p'
        'mbdtbx_s32k\mscripts\utils\mbd_s32k_copy_required_files.p'
        };
    
    deletedFiles = {
        
        };
    
    if isempty(which('mbd_find_s32k_root'))
        fprintf('Toolbox %s not found!\n\n', tbxName); 
        return;
    end
    
    tbxRoot = mbd_find_s32k_root();
    fprintf('Toolbox path: %s\n\n', tbxRoot);
    
    datenums = zeros(length(modifiedFiles), 1);
    
    for i = 1 : length(modifiedFiles)
        modifiedFile = modifiedFiles{i};
        d = dir(fullfile(tbxName, modifiedFile));
        if ~isempty(d)
            datenums(i) = d.datenum;
        end
    end
    
    % Remove files
    for i = 1 : length(deletedFiles)
        deletedFile = deletedFiles{i};
        deletedFilePath = fullfile(tbxRoot, deletedFile);
        
        fprintf('Removing file: %s ... ', deletedFile);
        if exist(deletedFilePath, 'file')
            delete(deletedFilePath);

            % Delete leftover empty folders
            currentFolder = fileparts(deletedFilePath);
            while ~strcmp(currentFolder, tbxRoot)
                if ~isfolder(currentFolder)
                    break;
                end
                folderContent = dir(currentFolder);
                folderContent = folderContent(~ismember({folderContent.name}, {'.','..'}));
                if ~isempty(folderContent)
                    break;
                end
                if contains(path, currentFolder)
                    rmpath(genpath(currentFolder));
                end

                rmdir(currentFolder, 's');
                currentFolder = fileparts(currentFolder);
            end

            if exist(deletedFilePath, 'file')
                fprintf('Error\n');
                status = -1;
            else
                fprintf('Done\n');
            end
        else
            fprintf('File already removed\n');
        end
    end
    
    if ~isempty(deletedFiles)
        fprintf('\n');
    end
    
    % Copy files
    for i = 1 : length(modifiedFiles)        
        modifiedFile = modifiedFiles{i};
        
        fprintf('Copying file: %s ... ', modifiedFile);
        
        [fileDir, ~, ~] = fileparts(modifiedFile);
        
        destFileDir = fullfile(tbxRoot, fileDir);
        if ~exist(destFileDir, 'dir')
            mkdir(destFileDir);
        end
        
        copyfile(fullfile(tbxName, modifiedFile), fullfile(tbxRoot, modifiedFile));
        
        d = dir(fullfile(tbxRoot, modifiedFile));
        if isempty(d) || datenums(i) ~= d.datenum
            fprintf('Error\n');
            status = -2;
        else
            fprintf('Done\n');
        end
    end
    
    if status < 0
        fprintf('\nError installing the patch! Error: %d\n\n', status);
    else
        mbd_s32k_path
        fprintf('\nPatch was installed successfully!\n\n');
    end
end