% Load general settings
BMS_settings;

% LiFe settings
Safety.UVP_limit = 2800;     %[mV]       UVP limit 
Safety.OVP_limit = 3650;     %[mV]       OVP limit 
Safety.UVP_Stack = 2800;      %[mV]        UVP of Stack
Safety.OVP_Stack = 3650;    %[mV]        OVP of Stack

